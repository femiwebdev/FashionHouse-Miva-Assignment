# FashionHouseBySE
This is an Assignment themed build, its an assignment designated to my group and what is achieved is a fashion house store with varieties of outfits that can be bought.
